﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using IronXL;

namespace IronXL_vs_OpenXML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertText_OpenXML(@"C:\Temp\OpenXML_Ex.xlsx", "Inserted Text from OpenXML");
        }

        public static void InsertText_OpenXML(string strFileName, string strContent)
        {
            using (SpreadsheetDocument objSpreadSheet = SpreadsheetDocument.Open(strFileName, true))
            {
                SharedStringTablePart objSharedStringTable;

                if (objSpreadSheet.WorkbookPart.GetPartsOfType<SharedStringTablePart>().Count() > 0)
                {
                    objSharedStringTable = objSpreadSheet.WorkbookPart.GetPartsOfType<SharedStringTablePart>().First();
                }
                else
                {
                    objSharedStringTable = objSpreadSheet.WorkbookPart.AddNewPart<SharedStringTablePart>();
                }

                if (objSharedStringTable.SharedStringTable == null)
                {
                    objSharedStringTable.SharedStringTable = new SharedStringTable();
                }

                int index = 0;
                int i = 0;

                foreach (SharedStringItem item in objSharedStringTable.SharedStringTable.Elements<SharedStringItem>())
                {
                    if (item.InnerText == strContent)
                    {
                        index =  i;
                    }

                    i++;

                }
                objSharedStringTable.SharedStringTable.AppendChild(new SharedStringItem(new Text(strContent)));
                objSharedStringTable.SharedStringTable.Save();

                WorkbookPart objWorkbook = objSpreadSheet.WorkbookPart;

                WorksheetPart objWorksheetPart = objWorkbook.AddNewPart<WorksheetPart>();
                objWorksheetPart.Worksheet = new Worksheet(new SheetData());
                objWorksheetPart.Worksheet.Save();

                Sheets objWorksheets = objWorkbook.Workbook.GetFirstChild<Sheets>();
                string strWorksheetID = objWorkbook.GetIdOfPart(objWorksheetPart);

                uint uintSheetID = 1;
                if (objWorksheets.Elements<Sheet>().Count() > 0)
                {
                    uintSheetID = objWorksheets.Elements<Sheet>().Select(s => s.SheetId.Value).Max() + 1;
                }

                string strSheetName = "OpenXML_Sheet" + uintSheetID;

                Sheet objSheet = new Sheet() { Id = strWorksheetID, SheetId = uintSheetID, Name = strSheetName };
                objWorksheets.Append(objSheet);
                objWorkbook.Workbook.Save();

                Worksheet objWorksheet = objWorksheetPart.Worksheet;
                SheetData objData = objWorksheet.GetFirstChild<SheetData>();

                string strColumn = "B";
                uint uintRow = 3;

                string strReference = strColumn + uintRow;

                DocumentFormat.OpenXml.Spreadsheet.Cell objCell = null; 

                Row objRow;
                if (objData.Elements<Row>().Where(r => r.RowIndex == uintRow).Count() != 0)
                {
                    objRow = objData.Elements<Row>().Where(r => r.RowIndex == uintRow).First();
                }
                else
                {
                    objRow = new Row() { RowIndex = uintRow };
                    objData.Append(objRow);
                }

                if (objRow.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Where(c => c.CellReference.Value == strColumn + uintRow).Count() > 0)
                {
                    objCell = objRow.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Where(c => c.CellReference.Value == strReference).First();
                }
                else
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell objRefCell = null;
                    foreach (DocumentFormat.OpenXml.Spreadsheet.Cell tmpCell in objRow.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>())
                    {
                        if (tmpCell.CellReference.Value.Length == strReference.Length)
                        {
                            if (string.Compare(tmpCell.CellReference.Value, strReference, true) > 0)
                            {
                                objRefCell = tmpCell;
                                break;
                            }
                        }
                    }

                    DocumentFormat.OpenXml.Spreadsheet.Cell objNewCell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellReference = strReference };
                    objRow.InsertBefore(objNewCell, objRefCell);

                    objWorksheet.Save();


                    objNewCell.CellValue = new CellValue(strContent.ToString());
                    objNewCell.DataType = new EnumValue<CellValues>(CellValues.SharedString);

                    objWorksheetPart.Worksheet.Save();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {


                WorkBook workbook = WorkBook.Create(ExcelFileFormat.XLSX);
                var sheet = workbook.CreateWorkSheet("My Sheet");
                sheet["A1"].Value = "IronXL";
                workbook.SaveAs("IronXLWorkbook");

        }
    }
}
